# AegisOps Terraform — Self-managed Kubernetes on EC2

This Terraform project creates the AWS network and three EC2 instances for a kubeadm-based Kubernetes lab:
- 1 Ubuntu 24.04 control-plane instance in a public subnet
- 2 Ubuntu 24.04 worker instances in private subnets
- VPC, Internet Gateway, public/private route tables, and a NAT Gateway
- A shared node security group with restricted administrator SSH/API access
- Encrypted gp3 root volumes and IMDSv2 required

It does **not** create EKS, install Kubernetes, or run Ansible. Use the repository's Ansible playbooks after Terraform finishes.

## Architecture

```text
Internet
   |
Internet Gateway
   |
Public subnet (10.20.1.0/24)
   |-- Control plane EC2 (public IP; SSH/API limited to admin_cidr)
   |-- NAT Gateway + Elastic IP
          |
          +-- Private subnet 1 (10.20.11.0/24) -- Worker 1
          +-- Private subnet 2 (10.20.12.0/24) -- Worker 2
```

Workers have no public IP. Their outbound package and image downloads use NAT.

## Prerequisites

1. Terraform >= 1.6.
2. AWS CLI configured with credentials for the target account.
3. An EC2 key pair already created in the selected region.
4. Your current public IPv4 address in CIDR notation, normally `/32`.

Do not use `0.0.0.0/0` for `admin_cidr`.

## Deploy from the root Terraform directory

Run commands from `infrastructure/terraform`:

```bash
cp terraform.tfvars.example terraform.tfvars
```

Edit `terraform.tfvars`:
- `admin_cidr`: your public IP, e.g. `198.51.100.25/32` (replace with your real IP).
- `key_name`: exact EC2 key pair name in `ap-south-1`.

Then:

```bash
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
terraform output
```

The `terraform.tfvars` file is ignored by Git. Never commit credentials, private keys, `terraform.tfstate`, or `tfplan`.

## Deploy using the dev environment wrapper

Alternatively:

```bash
cd environments/dev
cp terraform.tfvars.example terraform.tfvars
# Edit admin_cidr and key_name
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
terraform output
```

Use one deployment path only (root OR environments/dev), not both.

## Connect

Use the `ssh_command` Terraform output and replace `KEY.pem` with your local key path:

```bash
ssh -i /path/to/KEY.pem ubuntu@CONTROL_PLANE_PUBLIC_IP
```

On Windows PowerShell, for example:

```powershell
ssh -i "$HOME\Downloads\YOUR_KEY.pem" ubuntu@CONTROL_PLANE_PUBLIC_IP
```

For private workers, connect through the control plane using SSH ProxyJump. Example (run from your laptop):

```bash
ssh -i /path/to/KEY.pem -J ubuntu@CONTROL_PLANE_PUBLIC_IP ubuntu@WORKER_PRIVATE_IP
```

## Important security and operational notes

- The Kubernetes API port 6443 is exposed only to `admin_cidr`; cluster nodes communicate over their shared security group.
- Node-to-node traffic is allowed within the shared security group so kubeadm, kubelet, and the selected CNI can communicate. For production, narrow this by protocol and port.
- The single NAT Gateway reduces lab cost but is a single point of failure and incurs hourly plus data-processing charges.
- EC2, EBS, Elastic IP/NAT Gateway, and data transfer can incur charges. Destroy the lab when not in use.
- The `t3.large` control plane and two `t3.medium` workers are starting lab sizes, not production sizing.
- This is a learning environment, not a production-ready hardened cluster.
- This project does not create IAM roles because the kubeadm nodes do not require AWS API permissions for the planned lab. Add narrowly scoped instance roles only if later components need AWS API access.

## Destroy resources

From the same directory where you ran `terraform apply`:

```bash
terraform destroy
```

Confirm the destroy plan carefully. This removes the VPC, instances, NAT Gateway, and related resources.
