terraform {
  required_version = ">= 1.6.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "Terraform"
    }
  }
}

module "aegisops" {
  source = "../../"

  aws_region                  = var.aws_region
  project_name                = var.project_name
  environment                 = var.environment
  vpc_cidr                    = var.vpc_cidr
  public_subnet_cidr          = var.public_subnet_cidr
  private_subnet_cidrs        = var.private_subnet_cidrs
  admin_cidr                  = var.admin_cidr
  key_name                    = var.key_name
  control_plane_instance_type = var.control_plane_instance_type
  worker_instance_type        = var.worker_instance_type
  worker_count                = var.worker_count
  root_volume_size            = var.root_volume_size
  enable_nat_gateway          = var.enable_nat_gateway
  single_nat_gateway          = var.single_nat_gateway
}

variable "aws_region" { type = string }
variable "project_name" { type = string }
variable "environment" { type = string }
variable "vpc_cidr" { type = string }
variable "public_subnet_cidr" { type = string }
variable "private_subnet_cidrs" { type = list(string) }
variable "admin_cidr" { type = string }
variable "key_name" { type = string }
variable "control_plane_instance_type" { type = string }
variable "worker_instance_type" { type = string }
variable "worker_count" { type = number }
variable "root_volume_size" { type = number }
variable "enable_nat_gateway" { type = bool }
variable "single_nat_gateway" { type = bool }

output "control_plane_public_ip" { value = module.aegisops.control_plane_public_ip }
output "control_plane_private_ip" { value = module.aegisops.control_plane_private_ip }
output "worker_private_ips" { value = module.aegisops.worker_private_ips }
output "vpc_id" { value = module.aegisops.vpc_id }
output "ssh_command" { value = module.aegisops.ssh_command }
