# Input variables are declared in main.tf for this environment wrapper.
