data "aws_availability_zones" "available" {
  state = "available"
}

data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"] # Canonical

  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd-gp3/ubuntu-noble-24.04-amd64-server-*"]
  }

  filter {
    name   = "architecture"
    values = ["x86_64"]
  }

  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

locals {
  name_prefix = "${var.project_name}-${var.environment}"
  azs         = slice(data.aws_availability_zones.available.names, 0, 2)

  worker_subnets = {
    for index, cidr in var.private_subnet_cidrs :
    tostring(index) => {
      cidr = cidr
      az   = local.azs[index % length(local.azs)]
    }
  }
}

module "vpc" {
  source = "./modules/vpc"

  name                 = local.name_prefix
  vpc_cidr             = var.vpc_cidr
  public_subnet_cidr   = var.public_subnet_cidr
  public_subnet_az     = local.azs[0]
  private_subnets      = local.worker_subnets
  enable_nat_gateway   = var.enable_nat_gateway
  single_nat_gateway   = var.single_nat_gateway
}

module "security" {
  source = "./modules/security"

  name       = local.name_prefix
  vpc_id     = module.vpc.vpc_id
  admin_cidr = var.admin_cidr
}

module "compute" {
  source = "./modules/compute"

  name                         = local.name_prefix
  ami_id                       = data.aws_ami.ubuntu.id
  key_name                     = var.key_name
  control_plane_instance_type  = var.control_plane_instance_type
  worker_instance_type         = var.worker_instance_type
  worker_count                 = var.worker_count
  root_volume_size             = var.root_volume_size
  control_plane_subnet_id      = module.vpc.public_subnet_id
  worker_subnet_ids            = module.vpc.private_subnet_ids
  security_group_id            = module.security.node_security_group_id
}
