resource "aws_security_group" "nodes" {
  name        = "${var.name}-k8s-nodes-sg"
  description = "AegisOps Kubernetes node traffic"
  vpc_id      = var.vpc_id

  # SSH access is limited to the administrator's public IP/CIDR.
  ingress {
    description = "SSH from administrator"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [var.admin_cidr]
  }

  # Kubernetes API access from administrator and from cluster nodes.
  ingress {
    description = "Kubernetes API from administrator"
    from_port   = 6443
    to_port     = 6443
    protocol    = "tcp"
    cidr_blocks = [var.admin_cidr]
  }

  # All node-to-node traffic inside this security group is allowed.
  ingress {
    description = "Node-to-node Kubernetes traffic"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    self        = true
  }

  # Calico BGP (only relevant if using BGP mode; harmless for this lab).
  ingress {
    description = "Calico BGP between nodes"
    from_port   = 179
    to_port     = 179
    protocol    = "tcp"
    self        = true
  }

  egress {
    description = "Outbound internet and cluster traffic"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = { Name = "${var.name}-k8s-nodes-sg" }
}
