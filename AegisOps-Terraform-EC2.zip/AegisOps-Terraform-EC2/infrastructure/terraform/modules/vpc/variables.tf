variable "name" { type = string }
variable "vpc_cidr" { type = string }
variable "public_subnet_cidr" { type = string }
variable "public_subnet_az" { type = string }
variable "private_subnets" {
  type = map(object({
    cidr = string
    az   = string
  }))
}
variable "enable_nat_gateway" { type = bool }
variable "single_nat_gateway" { type = bool }
