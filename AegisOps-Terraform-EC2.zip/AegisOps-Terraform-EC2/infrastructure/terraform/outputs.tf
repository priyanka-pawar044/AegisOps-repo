output "vpc_id" {
  description = "AegisOps VPC ID."
  value       = module.vpc.vpc_id
}

output "public_subnet_id" {
  description = "Public subnet ID containing the control plane."
  value       = module.vpc.public_subnet_id
}

output "private_subnet_ids" {
  description = "Private subnet IDs containing worker nodes."
  value       = module.vpc.private_subnet_ids
}

output "control_plane_public_ip" {
  description = "Public IPv4 address of the Kubernetes control-plane node."
  value       = module.compute.control_plane_public_ip
}

output "control_plane_private_ip" {
  description = "Private IPv4 address of the Kubernetes control-plane node."
  value       = module.compute.control_plane_private_ip
}

output "worker_private_ips" {
  description = "Private IPv4 addresses of Kubernetes worker nodes."
  value       = module.compute.worker_private_ips
}

output "ssh_command" {
  description = "SSH command template. Replace KEY.pem with the local path to your private key."
  value       = "ssh -i KEY.pem ubuntu@${module.compute.control_plane_public_ip}"
}

output "nat_gateway_ids" {
  description = "NAT Gateway IDs. NAT Gateway hourly and data processing charges apply."
  value       = module.vpc.nat_gateway_ids
}
