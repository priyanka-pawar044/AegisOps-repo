variable "aws_region" {
  description = "AWS region for the AegisOps lab."
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  description = "Short project identifier used in resource names."
  type        = string
  default     = "aegisops"
}

variable "environment" {
  description = "Deployment environment."
  type        = string
  default     = "dev"
}

variable "vpc_cidr" {
  description = "CIDR block for the VPC."
  type        = string
  default     = "10.20.0.0/16"
}

variable "public_subnet_cidr" {
  description = "Public subnet CIDR for the control plane and NAT gateway."
  type        = string
  default     = "10.20.1.0/24"
}

variable "private_subnet_cidrs" {
  description = "Private subnet CIDRs for Kubernetes workers."
  type        = list(string)
  default     = ["10.20.11.0/24", "10.20.12.0/24"]

  validation {
    condition     = length(var.private_subnet_cidrs) >= 2
    error_message = "Provide at least two private subnet CIDRs."
  }
}

variable "admin_cidr" {
  description = "Your public IPv4 address in CIDR notation, e.g. 203.0.113.10/32. Used for SSH and the Kubernetes API."
  type        = string

  validation {
    condition     = can(cidrhost(var.admin_cidr, 0))
    error_message = "admin_cidr must be a valid CIDR block, preferably your public IP with /32."
  }
}

variable "key_name" {
  description = "Name of an existing EC2 key pair in the selected AWS region."
  type        = string
}

variable "control_plane_instance_type" {
  description = "EC2 instance type for the Kubernetes control plane."
  type        = string
  default     = "t3.large"
}

variable "worker_instance_type" {
  description = "EC2 instance type for each Kubernetes worker."
  type        = string
  default     = "t3.medium"
}

variable "worker_count" {
  description = "Number of private Kubernetes worker nodes."
  type        = number
  default     = 2

  validation {
    condition     = var.worker_count >= 2 && var.worker_count <= 3
    error_message = "worker_count must be 2 or 3 for this lab."
  }
}

variable "root_volume_size" {
  description = "Encrypted gp3 root volume size in GiB."
  type        = number
  default     = 40
}

variable "enable_nat_gateway" {
  description = "Create a NAT Gateway so private workers can download packages and container images."
  type        = bool
  default     = true
}

variable "single_nat_gateway" {
  description = "Use one NAT Gateway to reduce lab cost. This is not a highly available production design."
  type        = bool
  default     = true
}
