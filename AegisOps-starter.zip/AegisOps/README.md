# AegisOps — Self-Healing AIOps Platform

Self-managed Kubernetes on AWS EC2 using kubeadm (not EKS).

## Architecture

- 1 public EC2 control-plane node (also the SSH administration/jump host)
- 2 private EC2 worker nodes
- Terraform provisions VPC, public/private subnets, IGW, NAT Gateway, routes, security group and EC2 instances
- Ansible installs containerd, kubeadm, kubelet and kubectl; initializes the control plane; joins workers; installs Calico
- Kubernetes workloads: payment-api, AegisOps FastAPI engine, Prometheus/Grafana/Loki/Alertmanager and Argo CD

## Important cost and safety notes

This is a learning environment, not a production HA cluster. A single control plane is a single point of failure. A NAT Gateway and three EC2 instances incur ongoing charges. Set an AWS Budget before applying Terraform. Run `terraform destroy` when finished with the lab. Back up anything you need first.

The Terraform state in this starter is local. For a team/long-lived environment, migrate it to an encrypted S3 backend with state locking.

Do not expose Kubernetes API port 6443 or SSH to `0.0.0.0/0`. Set `admin_cidr` to your public IP in CIDR notation, e.g. `203.0.113.10/32`.

## Prerequisites

- AWS account and permissions to create VPC, EC2, EIP, NAT Gateway, routes and security groups
- AWS CLI configured locally (`aws configure` or SSO)
- Terraform
- An existing EC2 key pair in the selected AWS region
- WSL2 Ubuntu or another Linux/macOS terminal with Ansible and Python
- Git

## Build order

1. Provision EC2 infrastructure: `infra/terraform`
2. Create Ansible inventory from Terraform outputs
3. Install Kubernetes with kubeadm using Ansible
4. Configure kubectl on your workstation
5. Deploy the payment API
6. Install observability and Argo CD
7. Deploy the AegisOps engine
8. Add incident diagnosis, policies, RAG, MCP and verification iteratively

See `docs/BUILD_GUIDE.md` for exact commands.

## Repository map

```text
AegisOps/
├── infra/terraform/          # AWS networking and EC2
├── ansible/                  # kubeadm + containerd + Calico
├── applications/payment-api/ # failure-injectable demo service
├── aegisops-engine/          # FastAPI incident webhook and collectors
├── kubernetes/               # app and engine manifests
├── monitoring/               # Helm values and Prometheus rules
├── gitops/                   # Argo CD Application
├── .github/workflows/        # CI pipeline
└── docs/                     # build, test and security guide
```

## Current implementation status

This is a starter repository with infrastructure automation and a working demonstration path. AI provider integration, production-grade RAG ingestion, MCP tools, persistent incident storage, approval UI and full GitOps rollback workflow are extension milestones—not falsely represented as complete.
