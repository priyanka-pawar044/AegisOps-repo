from datetime import datetime, timezone
from uuid import uuid4

def normalize_alert(alert: dict) -> dict:
    labels = alert.get("labels", {})
    annotations = alert.get("annotations", {})
    return {
        "incident_id": f"AEGIS-{uuid4().hex[:8].upper()}",
        "alert_name": labels.get("alertname", "UnknownAlert"),
        "service": labels.get("service", labels.get("app", "unknown")),
        "severity": labels.get("severity", "warning"),
        "status": alert.get("status", "firing"),
        "summary": annotations.get("summary", ""),
        "description": annotations.get("description", ""),
        "starts_at": alert.get("startsAt"),
        "received_at": datetime.now(timezone.utc).isoformat()
    }
