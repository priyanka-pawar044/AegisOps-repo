from fastapi import FastAPI
from app.webhook import router as webhook_router

app = FastAPI(
    title="AegisOps Incident Engine",
    version="0.1.0",
    description="Incident intake and diagnostic orchestration starter"
)

app.include_router(webhook_router)

@app.get("/health")
def health():
    return {"service": "aegisops-engine", "status": "healthy"}
