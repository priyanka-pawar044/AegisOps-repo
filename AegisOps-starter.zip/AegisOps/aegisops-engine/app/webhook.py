from fastapi import APIRouter, Request, HTTPException
from app.incident import normalize_alert

router = APIRouter()

@router.post("/webhook")
async def receive_alert(request: Request):
    try:
        payload = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail="Invalid JSON") from exc

    alerts = payload.get("alerts", [])
    incidents = [normalize_alert(alert) for alert in alerts]

    # Starter behavior: log normalized incidents.
    # Next milestone: persist in PostgreSQL and enqueue asynchronous diagnosis.
    for incident in incidents:
        print({"event": "incident_received", **incident})

    return {"received": len(incidents), "incidents": incidents}
