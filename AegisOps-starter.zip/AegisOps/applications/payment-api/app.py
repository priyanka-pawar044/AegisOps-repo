import os
import time
from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from prometheus_client import Counter, Histogram, generate_latest, CONTENT_TYPE_LATEST

app = FastAPI(title="AegisOps Payment API")

REQUESTS = Counter(
    "payment_requests_total",
    "Total payment requests",
    ["status"]
)
LATENCY = Histogram(
    "payment_request_duration_seconds",
    "Payment request latency"
)

@app.get("/")
def root():
    return {"service": "payment-api", "status": "running"}

@app.get("/health")
def health():
    return {"status": "healthy"}

@app.get("/payment")
def payment():
    start = time.time()
    fail_mode = os.getenv("FAIL_MODE", "false").lower() == "true"
    slow_mode = os.getenv("SLOW_MODE", "false").lower() == "true"

    if slow_mode:
        time.sleep(2)

    if fail_mode:
        REQUESTS.labels(status="failed").inc()
        LATENCY.observe(time.time() - start)
        raise HTTPException(status_code=500, detail="Simulated database connection failure")

    REQUESTS.labels(status="success").inc()
    LATENCY.observe(time.time() - start)
    return {"message": "Payment successful"}

@app.get("/metrics")
def metrics():
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)
