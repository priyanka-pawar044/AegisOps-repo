# AegisOps build guide

## 0. Set variables

Use your actual values; never commit private keys or credentials.

```bash
export AWS_REGION=ap-south-1
export TF_VAR_region="$AWS_REGION"
export TF_VAR_key_name="YOUR_EXISTING_EC2_KEY_PAIR"
export TF_VAR_admin_cidr="YOUR_PUBLIC_IP/32"
```

Find your public IP from a trusted IP-check service and enter it as `/32`. Do not use `0.0.0.0/0`.

## 1. Provision AWS infrastructure

```bash
cd infra/terraform
cp terraform.tfvars.example terraform.tfvars
# Edit terraform.tfvars: key_name and admin_cidr are required.
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
terraform apply tfplan
terraform output
```

Record `control_plane_public_ip`, `control_plane_private_ip`, `worker_private_ips` and `ssh_private_key_name`.

## 2. Prepare Ansible

On WSL/Linux/macOS:

```bash
sudo apt update
sudo apt install -y ansible python3-pip
python3 -m pip install --user boto3 botocore
```

Create `ansible/inventory.ini` using the Terraform outputs:

```ini
[control_plane]
control-plane ansible_host=CONTROL_PLANE_PUBLIC_IP ansible_user=ubuntu

[workers]
worker-1 ansible_host=WORKER_1_PRIVATE_IP ansible_user=ubuntu
worker-2 ansible_host=WORKER_2_PRIVATE_IP ansible_user=ubuntu

[k8s_cluster:children]
control_plane
workers

[k8s_cluster:vars]
ansible_ssh_private_key_file=PATH_TO_YOUR_PEM
ansible_ssh_common_args=-o ProxyJump=ubuntu@CONTROL_PLANE_PUBLIC_IP
```

The control-plane host itself should not use ProxyJump. If Ansible applies the group variable to it, add a host-specific override:
`control-plane ansible_ssh_common_args=''`.

Make sure the private key is protected:
`chmod 600 PATH_TO_YOUR_PEM`.

The control-plane instance is reachable directly from your admin IP. Workers have no public IP; SSH reaches them through the control-plane jump host.

## 3. Install Kubernetes

```bash
cd ansible
ansible-playbook -i inventory.ini site.yml
```

The playbook installs containerd and Kubernetes packages, initializes the control plane, installs Calico, and joins the two workers.

If the join step fails, inspect:
```bash
kubectl get nodes -o wide
sudo journalctl -u kubelet -n 100 --no-pager
sudo crictl info
```

## 4. Configure kubectl locally

On the control-plane instance:
```bash
sudo cat /etc/kubernetes/admin.conf
```

Prefer copying the kubeconfig securely with `scp` rather than pasting it into chat or committing it. From your workstation:
```bash
mkdir -p ~/.kube
scp -o ProxyJump=ubuntu@CONTROL_PLANE_PUBLIC_IP \
  ubuntu@CONTROL_PLANE_PRIVATE_IP:/tmp/admin.conf ~/.kube/config
chmod 600 ~/.kube/config
```

Before this, on the control plane, create the temporary copy:
```bash
sudo cp /etc/kubernetes/admin.conf /tmp/admin.conf
sudo chown ubuntu:ubuntu /tmp/admin.conf
chmod 600 /tmp/admin.conf
```

For a safer long-term setup, create a restricted user kubeconfig instead of distributing the cluster-admin kubeconfig. Delete `/tmp/admin.conf` after copying.

Update the kubeconfig server address to the control-plane private IP if needed:
```bash
kubectl config set-cluster kubernetes \
  --server=https://CONTROL_PLANE_PRIVATE_IP:6443
```
The exact cluster name may differ; inspect `kubectl config get-clusters` first.

Verify:
```bash
kubectl get nodes -o wide
kubectl get pods -A
```

## 5. Deploy payment API

Build and push the image to a registry reachable by your nodes (ECR is recommended; Docker Hub can be used for a first test). Replace the image in `kubernetes/payment-api/deployment.yaml`.

```bash
kubectl create namespace aegisops
kubectl apply -f kubernetes/payment-api/
kubectl rollout status deployment/payment-api -n aegisops
kubectl port-forward -n aegisops svc/payment-api 8080:80
curl http://127.0.0.1:8080/
curl http://127.0.0.1:8080/payment
```

## 6. Install monitoring

```bash
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo add grafana https://grafana.github.io/helm-charts
helm repo update

helm upgrade --install monitoring prometheus-community/kube-prometheus-stack \
  --namespace monitoring --create-namespace \
  -f monitoring/kube-prometheus-stack-values.yaml

kubectl apply -f monitoring/payment-api-servicemonitor.yaml
kubectl apply -f monitoring/payment-api-alerts.yaml
```

Loki chart configuration changes across chart versions. Review the chart's current values before installing; then install Loki and Grafana Alloy using the values appropriate to the pinned chart versions. This starter intentionally does not assume a version-sensitive Loki values file.

## 7. Install Argo CD

```bash
kubectl create namespace argocd
kubectl apply -n argocd -f https://raw.githubusercontent.com/argoproj/argo-cd/stable/manifests/install.yaml
kubectl get pods -n argocd
```

Edit `gitops/payment-api-application.yaml` with your Git repository URL, then:
```bash
kubectl apply -f gitops/payment-api-application.yaml
```

## 8. Run AegisOps engine locally first

```bash
cd aegisops-engine
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Test:
```bash
curl http://127.0.0.1:8000/health
```

Configure Alertmanager to send webhooks to the in-cluster AegisOps service after deploying the engine. Do not point a cluster-internal Alertmanager at `localhost` on your laptop.

## 9. Cost shutdown

When you are finished and have backed up anything important:
```bash
cd infra/terraform
terraform destroy
```
This removes the Terraform-managed infrastructure, including NAT Gateway and EC2 instances. Verify the AWS console for leftover EBS volumes, snapshots, Elastic IPs, load balancers or other resources created outside Terraform.
