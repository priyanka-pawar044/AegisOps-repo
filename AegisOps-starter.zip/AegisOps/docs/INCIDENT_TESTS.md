# Incident simulation and acceptance tests

Run these only in your isolated development cluster.

## Test A: application returns HTTP 500

```bash
kubectl set env deployment/payment-api FAIL_MODE=true -n aegisops
kubectl port-forward -n aegisops svc/payment-api 8080:80
# In another terminal:
while true; do curl -s -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8080/payment; sleep 1; done
```

Expected: HTTP 500 responses, Prometheus counter increments, alert fires after the rule's `for` duration, Alertmanager posts to the AegisOps webhook once webhook routing is configured.

Recover:
```bash
kubectl set env deployment/payment-api FAIL_MODE=false -n aegisops
```

## Test B: slow responses

```bash
kubectl set env deployment/payment-api SLOW_MODE=true -n aegisops
```
Expected: request latency increases. Add a histogram-based latency alert as a follow-up exercise.

Recover:
```bash
kubectl set env deployment/payment-api SLOW_MODE=false -n aegisops
```

## Acceptance checklist

- [ ] All Kubernetes nodes are Ready
- [ ] Calico pods are Ready
- [ ] Payment API has two available replicas
- [ ] Prometheus scrapes `payment-api`
- [ ] Grafana can query payment metrics
- [ ] Loki/Alloy collect application logs
- [ ] Alertmanager reaches AegisOps webhook
- [ ] Incident payload is normalized and logged
- [ ] Policy engine rejects unapproved actions
- [ ] Human approval is recorded before rollback
- [ ] Recovery is verified over a sustained observation window
