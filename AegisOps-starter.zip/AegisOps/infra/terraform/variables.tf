variable "region" {
  description = "AWS region"
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  type    = string
  default = "aegisops"
}

variable "key_name" {
  description = "Name of an existing EC2 key pair in this region"
  type        = string
}

variable "admin_cidr" {
  description = "Your public IPv4 address in CIDR notation, e.g. 203.0.113.10/32"
  type        = string
  validation {
    condition     = can(cidrnetmask(var.admin_cidr))
    error_message = "admin_cidr must be valid CIDR notation. Use your IP/32."
  }
}

variable "control_plane_instance_type" {
  type    = string
  default = "t3.large"
}

variable "worker_instance_type" {
  type    = string
  default = "t3.medium"
}

variable "worker_count" {
  type    = number
  default = 2
  validation {
    condition     = var.worker_count >= 2 && var.worker_count <= 3
    error_message = "For this lab, worker_count must be 2 or 3."
  }
}
